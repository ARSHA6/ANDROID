package com.arsha.powerreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.ImageView;

public class MyReceiver extends BroadcastReceiver {
    ImageView imageview;
    public MyReceiver(ImageView imageview)
    {
        this.imageview=imageview;
    }
    @Override
    public void onReceive(Context context, Intent intent) {
        switch (intent.getAction())
        {
            case Intent.ACTION_POWER_CONNECTED:
                imageview.setImageResource(R.drawable.battery);
            case Intent.ACTION_POWER_DISCONNECTED:
                imageview.setImageResource(R.drawable.discharging);
        }
    }
}
