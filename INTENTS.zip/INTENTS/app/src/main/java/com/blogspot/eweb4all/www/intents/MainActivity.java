package com.blogspot.eweb4all.www.intents;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void openMaps(View view) {
        EditText et = findViewById(R.id.address);
        String address = et.getText().toString();
        Toast.makeText(this,address, Toast.LENGTH_SHORT).show();
        Intent mapsIntent= new Intent();
        mapsIntent.setAction(Intent.ACTION_VIEW);
        Uri data = Uri.parse("geo:0,0?q="+address);
        mapsIntent.setData(data);
        startActivity(mapsIntent);

    }

    public void openBrowser(View view) {
        EditText et = findViewById(R.id.eturl);
        String link = et.getText().toString();
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        Uri data = Uri.parse("https://"+link);
        intent.setData(data);
        /* Intent intent= new Intent(Intent.ACTION_VIEW,Uri.parse("https://"+link));*/
        startActivity(intent);

    }

    public void onCall(View view) {
        EditText et = findViewById(R.id.phone);
        String number = et.getText().toString();
        Intent i = new Intent();
        i.setAction(Intent.ACTION_DIAL);
        Uri data =Uri.parse("tel:"+number);
        i.setData(data);
        startActivity(i);
    }

    public void nextActivity(View view) {
        // create an explicit intent
        Intent intent = new Intent(MainActivity.this,secondActivity.class);
        intent.putExtra("MSG","This is my First Message");
        startActivity(intent);
    }
}
